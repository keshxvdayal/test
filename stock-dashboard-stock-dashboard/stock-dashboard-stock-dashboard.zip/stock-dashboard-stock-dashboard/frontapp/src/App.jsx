import "./App.css";
import Dashboard from "./components/dashboard";

function App() {
  return <Dashboard />;
}

export default App;
