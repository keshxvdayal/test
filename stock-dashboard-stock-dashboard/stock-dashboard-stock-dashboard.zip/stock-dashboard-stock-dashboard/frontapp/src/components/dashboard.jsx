/* eslint-disable react/prop-types */

import { useEffect, useState } from "react";
import Header from "./header";


export function Card({ symbol="stock", closingPrices=[] }) {
  const [percent, setPercent] = useState(0);


  useEffect(() => {
    const prices = Object.values(closingPrices);
    const up = ((prices.slice(-1) - prices[0]) * 100) / prices[0];
    setPercent(up.toFixed(2));
  }, []);

  return (
    <>
      <div className="card shadow border-0 min-w-[200px]">
        <div className="card-body">
          <div className="row items-center">
            <div className="col">
              <strong className="text-muted text-lg d-block mb-2">
                { symbol.split(".")[0] }
              </strong>
            </div>
            <div className="col-auto">
              <div className="icon icon-shape bg-primary text-white text-lg rounded-circle">
                <i className="bi bi-people"></i>
              </div>
            </div>
          </div>
          <div className="mt-2 mb-0 text-lg">
            <span className="badge badge-pill bg-soft-success text-success me-2">
              <i className="bi bi-arrow-up me-1"></i>{percent}%
            </span>
          </div>
        </div>
      </div>
    </>
  );
}

function Dashboard() {
  const [consecutiveData, setConsecutiveData] = useState([]);

  useEffect(() => {
    fetch("http://127.0.0.1:8082/get_consecutive").then(async res => {
      const json = await res.json();
      if (json.error) {
        alert(json.error);
        return 0;
      }

      //console.log(json)
      setConsecutiveData(json);
    })
    
  }, []);

  return (
    <>
      <div className="d-flex flex-column flex-lg-row h-lg-full bg-surface-secondary">
        <div className="h-screen flex-grow-1 overflow-y-lg-auto">
          <Header />
          <main className="py-6 bg-surface-secondary">
            <div className="container-fluid">
              {/* fitler 1 */}
              <h3 className="text-slate-600">Stocks that went up for 3-5 consecutive days</h3>
              <br />
              <div className="row g-6 mb-6">
                <div className="flex gap-6">
                  {
                    consecutiveData.map((z, i) => <Card key={i} {...z} />)
                  }
                </div>
              </div>

              {/* filter 2 */}
              {/* <div className="flex justify-center mt-8">
                <div className=" m-2 bg-white p-4 rounded shadow border-0">
                  <div>
                    <p className=" font-bold text-black mb-2">Stocks at</p>
                    <p className="mb-2">10 Cent</p>
                    <button className="rounded-2xl border-2  border-indigo-500 text-black hover:shadow-indigo-500 bg-white px-4 font-semibold uppercase transition-all duration-300 hover:translate-x-[-4px] hover:translate-y-[-4px] hover:rounded-md hover:shadow-[4px_4px_0px_black] active:translate-x-[0px] active:translate-y-[0px] active:rounded-2xl active:shadow-none">
                      {" "}
                      Filter
                    </button>
                  </div>
                </div>
                <div className=" m-2 bg-white p-4 rounded shadow border-0">
                  <div>
                    <p className=" font-bold text-black mb-2">Stocks at</p>
                    <p className="mb-2">10-99 Cent</p>
                    <button className="rounded-2xl border-2 border-indigo-500 text-black hover:shadow-indigo-500 px-4 font-semibold uppercase  transition-all duration-300 hover:translate-x-[-4px] hover:translate-y-[-4px] hover:rounded-md hover:shadow-[4px_4px_0px_black]  active:translate-x-[0px] active:translate-y-[0px] active:rounded-2xl active:shadow-none">
                      {" "}
                      Filter
                    </button>
                  </div>
                </div>
                <div className=" m-2 bg-white p-4 rounded shadow border-0">
                  <div>
                    <p className=" font-bold text-black mb-2">Stocks at</p>
                    <p className="mb-2">1 Dollar</p>
                    <button className="rounded-2xl border-2  border-indigo-500 text-black hover:shadow-indigo-500  px-4 font-semibold uppercase transition-all duration-300 hover:translate-x-[-4px] hover:translate-y-[-4px] hover:rounded-md hover:shadow-[4px_4px_0px_black] active:translate-x-[0px] active:translate-y-[0px] active:rounded-2xl active:shadow-none">
                      {" "}
                      Filter
                    </button>
                  </div>
                </div>
              </div> */}

              <h3 className="mb-0">STOCKS</h3>
              <div className="card shadow border-0 mb-7">
                {/* <div className="table-responsive">
                  <table className="table table-hover table-nowrap">
                    <thead className="thead-light">
                      <tr>
                        <th scope="col">Name</th>
                        <th scope="col">50% Inc</th>
                        <th scope="col">100% Inc</th>
                        <th scope="col">200% Inc</th>
                        <th></th>
                      </tr>
                    </thead>
                  </table>
                </div>
                <div className="card-footer border-0 py-5">
                  <span className="text-muted text-sm">
                    Showing 10 items out of 250 results found
                  </span>
                </div> */}
              </div>

            </div>
          </main>
        </div>
      </div>
    </>
  );
}

export default Dashboard;
